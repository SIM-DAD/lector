"""OS keystore access via the `keyring` library.

Per README §3.2: backend is pinned explicitly at import time so a misconfigured
environment fails loud rather than silently falling back to a plaintext backend.

Service name is the constant `simdad-crypto`. Account name format is the
caller's responsibility; the convention is `{product}.{purpose}` (see README §4).
"""

from __future__ import annotations

import sys

import keyring
import keyring.errors

from .errors import KeyNotFoundError, KeystoreUnavailableError

SERVICE_NAME = "simdad-crypto"


def _pin_backend() -> None:
    """Select the platform-native keyring backend explicitly.

    Raises KeystoreUnavailableError if the expected backend cannot be loaded;
    the caller will then surface a remediation message instead of silently
    using a plaintext file backend.
    """
    try:
        if sys.platform == "win32":
            from keyring.backends.Windows import WinVaultKeyring

            keyring.set_keyring(WinVaultKeyring())  # type: ignore[no-untyped-call]
        elif sys.platform == "darwin":
            from keyring.backends.macOS import Keyring as MacKeyring

            keyring.set_keyring(MacKeyring())  # type: ignore[no-untyped-call]
        else:
            # Linux + other Unix; rely on the freedesktop.org Secret Service API.
            from keyring.backends.SecretService import Keyring as SecretServiceKeyring

            keyring.set_keyring(SecretServiceKeyring())  # type: ignore[no-untyped-call]
    except Exception as e:
        # Whatever broke loading the platform-native backend, we want the
        # caller to see KeystoreUnavailableError with the underlying detail
        # rather than a confusing ImportError or attribute lookup failure.
        raise KeystoreUnavailableError(
            f"could not load platform keyring backend: {e}"
        ) from e


_pin_backend()


def store_key(name: str, key_material: bytes) -> None:
    """Store key material in the OS keystore under SERVICE_NAME / name.

    `key_material` is bytes by API contract; we decode UTF-8 for storage so the
    keystore entry is human-recognisable in the OS UI (per README §4). Callers
    pass the age secret key string encoded as UTF-8 bytes.

    Replaces any existing entry with the same name without warning. The caller
    is responsible for migration if rotation invalidates past ciphertext.
    """
    if not isinstance(name, str) or not name:
        raise ValueError("name must be a non-empty string")
    if not isinstance(key_material, (bytes, bytearray)):
        raise TypeError("key_material must be bytes")

    try:
        value = key_material.decode("utf-8")
    except UnicodeDecodeError as e:
        raise ValueError(
            "key_material must be UTF-8 encodable; pass the age secret key "
            "string (AGE-SECRET-KEY-1...) encoded as UTF-8"
        ) from e

    try:
        keyring.set_password(SERVICE_NAME, name, value)
    except keyring.errors.KeyringError as e:
        raise KeystoreUnavailableError(f"keyring write failed: {e}") from e


def retrieve_key(name: str) -> bytes:
    """Return the bytes stored under SERVICE_NAME / name.

    Raises KeyNotFoundError if no entry exists.
    Raises KeystoreUnavailableError if the OS keystore cannot be reached.
    """
    if not isinstance(name, str) or not name:
        raise ValueError("name must be a non-empty string")

    try:
        value = keyring.get_password(SERVICE_NAME, name)
    except keyring.errors.KeyringError as e:
        raise KeystoreUnavailableError(f"keyring read failed: {e}") from e

    if value is None:
        raise KeyNotFoundError(
            f"no entry under service '{SERVICE_NAME}' / account '{name}'"
        )
    return value.encode("utf-8")


def _delete_key(name: str) -> None:
    """Internal: delete a key entry. Used by tests for cleanup.

    Not part of the four-function public API. If a future rotation flow needs
    explicit delete, that requires owner sign-off per README §2.
    """
    try:
        keyring.delete_password(SERVICE_NAME, name)
    except keyring.errors.PasswordDeleteError:
        # Already absent; idempotent.
        pass
    except keyring.errors.KeyringError as e:
        raise KeystoreUnavailableError(f"keyring delete failed: {e}") from e
