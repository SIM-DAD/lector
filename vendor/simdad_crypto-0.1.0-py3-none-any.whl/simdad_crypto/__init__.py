"""simdad-crypto: conservative file encryption + OS keystore for SIM DAD LLC products.

Public API (the four functions; per README §2, anything else requires owner sign-off):

    encrypt_file(path, recipient, *, overwrite=False) -> Path
    decrypt_file(path, identity, *, overwrite=False) -> Path
    store_key(name, key_material) -> None
    retrieve_key(name) -> bytes

Errors:

    simdad_crypto.errors.KeyNotFoundError
    simdad_crypto.errors.KeystoreUnavailableError
    simdad_crypto.errors.DecryptionError
    simdad_crypto.errors.OverwriteRefusedError

See README.md for threat model, implementation choices, and per-product
integration plan.
"""

from __future__ import annotations

from . import errors
from ._files import decrypt_file, encrypt_file
from ._keystore import retrieve_key, store_key

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "decrypt_file",
    "encrypt_file",
    "errors",
    "retrieve_key",
    "store_key",
]
