"""File encryption + decryption via pyrage (age v1).

Per README §3.1: pyrage chosen over PyNaCl because the age v1 spec already
made the file-format choices (header layout, nonce management, MAC, chunking)
that we don't want a one-developer module to make wrong in private.

Per README §2: encrypt_file appends `.age` to the input path; decrypt_file
strips the `.age` suffix. Both refuse to overwrite an existing destination
unless `overwrite=True` is passed.
"""

from __future__ import annotations

from pathlib import Path

import pyrage
import pyrage.x25519

from .errors import DecryptionError, OverwriteRefusedError

PathLike = str | Path
KeyLike = str | bytes

AGE_SUFFIX = ".age"


def _to_str(key: KeyLike, label: str) -> str:
    """Normalize a key argument (bytes or str) to a UTF-8 string."""
    if isinstance(key, (bytes, bytearray)):
        try:
            return key.decode("utf-8")
        except UnicodeDecodeError as e:
            raise ValueError(f"{label} bytes are not valid UTF-8") from e
    if isinstance(key, str):
        return key
    raise TypeError(f"{label} must be str or bytes; got {type(key).__name__}")


def encrypt_file(
    path: PathLike,
    recipient: KeyLike,
    *,
    overwrite: bool = False,
) -> Path:
    """Encrypt `path` to `path + ".age"` with the given X25519 recipient.

    Args:
        path: input file path (str or Path).
        recipient: age X25519 public key. Either the `age1...` string itself,
            or the same string encoded as UTF-8 bytes.
        overwrite: if True, replace an existing `.age` destination instead of
            raising OverwriteRefusedError. Defaults to False.

    Returns:
        Path to the newly written ciphertext file.

    Raises:
        FileNotFoundError: if `path` does not exist.
        OverwriteRefusedError: if the destination exists and overwrite=False.
    """
    src = Path(path)
    if not src.exists():
        raise FileNotFoundError(src)
    if src.is_dir():
        raise IsADirectoryError(f"{src} is a directory; encrypt_file takes a file path")

    dst = src.with_suffix(src.suffix + AGE_SUFFIX)
    if dst.exists() and not overwrite:
        raise OverwriteRefusedError(
            f"{dst} exists; pass overwrite=True to replace"
        )

    rcpt_str = _to_str(recipient, "recipient")
    rcpt = pyrage.x25519.Recipient.from_str(rcpt_str)

    plaintext = src.read_bytes()
    ciphertext = pyrage.encrypt(plaintext, [rcpt])
    dst.write_bytes(ciphertext)
    return dst


def decrypt_file(
    path: PathLike,
    identity: KeyLike,
    *,
    overwrite: bool = False,
) -> Path:
    """Decrypt the `.age` file at `path` using the given X25519 identity.

    Args:
        path: ciphertext file path. Must end in `.age`.
        identity: age X25519 secret key. Either the `AGE-SECRET-KEY-1...`
            string, or the same string encoded as UTF-8 bytes.
        overwrite: if True, replace an existing plaintext destination instead
            of raising OverwriteRefusedError. Defaults to False.

    Returns:
        Path to the newly written plaintext file (`path` minus the `.age` suffix).

    Raises:
        FileNotFoundError: if `path` does not exist.
        ValueError: if `path` does not end in `.age`.
        OverwriteRefusedError: if the plaintext destination exists and
            overwrite=False.
        DecryptionError: if pyrage cannot decrypt (wrong key, tampered file,
            or malformed input).
    """
    src = Path(path)
    if not src.exists():
        raise FileNotFoundError(src)
    if src.suffix != AGE_SUFFIX:
        raise ValueError(
            f"expected an '{AGE_SUFFIX}' file; got {src.name}"
        )

    dst = src.with_suffix("")  # strip the .age extension
    if dst.exists() and not overwrite:
        raise OverwriteRefusedError(
            f"{dst} exists; pass overwrite=True to replace"
        )

    ident_str = _to_str(identity, "identity")
    ident = pyrage.x25519.Identity.from_str(ident_str)

    ciphertext = src.read_bytes()
    try:
        plaintext = pyrage.decrypt(ciphertext, [ident])
    except Exception as e:
        # pyrage surfaces a variety of error types from the underlying Rust
        # crate; we normalize all of them to DecryptionError so callers have
        # one thing to catch.
        raise DecryptionError(f"decryption failed: {e}") from e

    dst.write_bytes(plaintext)
    return dst
