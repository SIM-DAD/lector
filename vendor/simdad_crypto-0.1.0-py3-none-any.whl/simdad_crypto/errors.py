"""Public error types for simdad_crypto.

Per README §2: anything not in this list is a bug.
"""

from __future__ import annotations


class SimdadCryptoError(Exception):
    """Base class for all simdad-crypto errors."""


class KeyNotFoundError(SimdadCryptoError):
    """retrieve_key was called for a name that does not exist in the keystore."""


class KeystoreUnavailableError(SimdadCryptoError):
    """The platform keystore could not be reached.

    Typical cause on Linux: headless session without a running Secret Service
    daemon. See README §7 for distro package names.
    """


class DecryptionError(SimdadCryptoError):
    """Decryption failed.

    Causes include: auth tag mismatch (tampered ciphertext or wrong key),
    malformed file, or an unexpected upstream error from pyrage.
    """


class OverwriteRefusedError(SimdadCryptoError):
    """Output path already exists and overwrite=False was passed.

    Pass overwrite=True to encrypt_file or decrypt_file to replace.
    """
